package com.myassistant.v1

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class ChatMessage(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AssistantApp(this) }
    }
}

@Composable
fun AssistantApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("assistant", Context.MODE_PRIVATE) }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var showSettings by remember { mutableStateOf(apiKey.isBlank()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var messages by remember {
        mutableStateOf(loadMessages(prefs))
    }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    MaterialTheme(
        colorScheme = darkColorScheme()
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Мой ассистент") },
                    actions = {
                        TextButton(onClick = { showSettings = true }) { Text("⚙") }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding)
            ) {
                if (showSettings) {
                    SettingsCard(
                        currentKey = apiKey,
                        onSave = {
                            apiKey = it.trim()
                            prefs.edit().putString("api_key", apiKey).apply()
                            showSettings = false
                        }
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.weight(1f).fillMaxWidth().padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messages) { msg ->
                            MessageBubble(msg)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Напиши сообщение…") },
                            enabled = !busy,
                            maxLines = 4
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(
                            enabled = !busy && input.isNotBlank() && apiKey.isNotBlank(),
                            onClick = {
                                val text = input.trim()
                                input = ""
                                messages = messages + ChatMessage("user", text)
                                saveMessages(prefs, messages)
                                busy = true
                                scope.launch {
                                    val answer = withContext(Dispatchers.IO) {
                                        OpenAIClient(apiKey).ask(messages)
                                    }
                                    messages = messages + ChatMessage("assistant", answer)
                                    saveMessages(prefs, messages)
                                    busy = false
                                }
                            }
                        ) {
                            Text(if (busy) "…" else "Отправить")
                        }
                    }

                    Text(
                        text = if (apiKey.isBlank()) "Сначала добавь API-ключ в ⚙" else "История сохраняется на этом устройстве",
                        modifier = Modifier.padding(start = 12.dp, end = 12.dp, bottom = 8.dp),
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }
}

@Composable
fun SettingsCard(currentKey: String, onSave: (String) -> Unit) {
    var key by remember { mutableStateOf(currentKey) }
    Card(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Настройка V1", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text(
                "Для V1 ключ вводится вручную и хранится локально. Для полноценного проекта позже лучше сделать собственный сервер-посредник, чтобы не хранить секрет API в приложении.",
                fontSize = 13.sp
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = key,
                onValueChange = { key = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("OpenAI API key") },
                singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            Button(onClick = { onSave(key) }, enabled = key.isNotBlank()) {
                Text("Сохранить")
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val mine = message.role == "user"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            tonalElevation = 2.dp,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            Text(
                text = message.text,
                modifier = Modifier.padding(12.dp)
            )
        }
    }
}

class OpenAIClient(private val apiKey: String) {
    private val client = OkHttpClient()

    fun ask(history: List<ChatMessage>): String {
        return try {
            val input = JSONArray()
            input.put(
                JSONObject()
                    .put("role", "developer")
                    .put("content", "Ты личный ассистент пользователя. Отвечай дружелюбно и естественно на русском языке, если пользователь не попросил другой язык.")
            )
            history.takeLast(20).forEach {
                input.put(JSONObject().put("role", it.role).put("content", it.text))
            }

            val body = JSONObject()
                .put("model", "gpt-5.6")
                .put("input", input)
                .toString()

            val request = Request.Builder()
                .url("https://api.openai.com/v1/responses")
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) return "Ошибка API (${response.code}): $raw"

                val json = JSONObject(raw)
                json.optString("output_text").ifBlank {
                    "Ответ получен, но приложение не смогло извлечь текст."
                }
            }
        } catch (e: Exception) {
            "Ошибка соединения: ${e.message ?: "неизвестная ошибка"}"
        }
    }
}

fun loadMessages(prefs: android.content.SharedPreferences): List<ChatMessage> {
    val raw = prefs.getString("messages", "[]") ?: "[]"
    val arr = JSONArray(raw)
    val result = mutableListOf<ChatMessage>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        result += ChatMessage(o.getString("role"), o.getString("text"))
    }
    return result
}

fun saveMessages(prefs: android.content.SharedPreferences, messages: List<ChatMessage>) {
    val arr = JSONArray()
    messages.takeLast(100).forEach {
        arr.put(JSONObject().put("role", it.role).put("text", it.text))
    }
    prefs.edit().putString("messages", arr.toString()).apply()
}
