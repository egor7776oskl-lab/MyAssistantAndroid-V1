#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <mutex>
#include <cstring>
#include "llama.h"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "MyAssistant", __VA_ARGS__)

static std::mutex g_mutex;
static llama_model * g_model = nullptr;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_myassistant_v1_LocalLlama_loadModel(JNIEnv * env, jobject, jstring path_) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_model) return JNI_TRUE;

    const char * path = env->GetStringUTFChars(path_, nullptr);
    llama_backend_init();

    llama_model_params params = llama_model_default_params();
    params.n_gpu_layers = 0;

    g_model = llama_model_load_from_file(path, params);
    env->ReleaseStringUTFChars(path_, path);

    if (!g_model) {
        LOGE("Unable to load model");
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

static std::string generate_text(const std::string & user_text, int max_tokens) {
    if (!g_model) return "Модель ещё не загружена.";

    const llama_vocab * vocab = llama_model_get_vocab(g_model);
    const char * tmpl = llama_model_chat_template(g_model, nullptr);

    llama_chat_message messages[2];
    messages[0] = {"system", "Ты личный AI-ассистент пользователя. Отвечай дружелюбно, естественно и по существу. По умолчанию отвечай на русском языке."};
    messages[1] = {"user", user_text.c_str()};

    int formatted_size = llama_chat_apply_template(
        tmpl, messages, 2, true, nullptr, 0
    );
    if (formatted_size <= 0) return "Не удалось сформировать запрос для модели.";

    std::vector<char> formatted(formatted_size + 1);
    if (llama_chat_apply_template(
            tmpl, messages, 2, true, formatted.data(), (int) formatted.size()) < 0) {
        return "Не удалось сформировать запрос для модели.";
    }

    std::string prompt(formatted.data(), formatted_size);

    int n_prompt = -llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(),
                                    nullptr, 0, true, true);
    if (n_prompt <= 0) return "Не удалось обработать запрос.";

    std::vector<llama_token> tokens(n_prompt);
    if (llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(),
                       tokens.data(), (int) tokens.size(), true, true) < 0) {
        return "Не удалось токенизировать запрос.";
    }

    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx = 4096;
    ctx_params.n_batch = 512;
    ctx_params.n_threads = 6;
    ctx_params.n_threads_batch = 6;

    llama_context * ctx = llama_init_from_model(g_model, ctx_params);
    if (!ctx) return "Не удалось создать контекст модели.";

    auto sampler_params = llama_sampler_chain_default_params();
    llama_sampler * sampler = llama_sampler_chain_init(sampler_params);
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    llama_batch batch = llama_batch_get_one(tokens.data(), tokens.size());
    std::string result;
    int n_pos = 0;

    while (n_pos + batch.n_tokens < n_prompt + max_tokens) {
        if (llama_decode(ctx, batch) != 0) {
            result = "Ошибка во время генерации ответа.";
            break;
        }
        n_pos += batch.n_tokens;

        llama_token token = llama_sampler_sample(sampler, ctx, -1);
        if (llama_vocab_is_eog(vocab, token)) break;

        char buf[256];
        int n = llama_token_to_piece(vocab, token, buf, sizeof(buf), 0, true);
        if (n > 0) result.append(buf, n);

        batch = llama_batch_get_one(&token, 1);
    }

    llama_sampler_free(sampler);
    llama_free(ctx);
    return result.empty() ? "Модель не вернула текст." : result;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_myassistant_v1_LocalLlama_generate(JNIEnv * env, jobject, jstring prompt_, jint maxTokens) {
    std::lock_guard<std::mutex> lock(g_mutex);
    const char * prompt = env->GetStringUTFChars(prompt_, nullptr);
    std::string answer = generate_text(prompt, maxTokens);
    env->ReleaseStringUTFChars(prompt_, prompt);
    return env->NewStringUTF(answer.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_myassistant_v1_LocalLlama_release(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_model) {
        llama_model_free(g_model);
        g_model = nullptr;
        llama_backend_free();
    }
}
