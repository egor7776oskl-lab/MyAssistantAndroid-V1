package com.myassistant.v1

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class ChatMessage(val role: String, val text: String)

private const val MODEL_URL =
    "https://huggingface.co/Qwen/Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q4_K_M.gguf"
private const val MODEL_FILE = "Qwen3-4B-Q4_K_M.gguf"

private object LocalLlama {
    init {
        System.loadLibrary("myassistant")
    }

    external fun loadModel(path: String): Boolean
    external fun generate(prompt: String, maxTokens: Int): String
    external fun release()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AssistantApp(this) }
    }

    override fun onDestroy() {
        LocalLlama.release()
        super.onDestroy()
    }
}

@Composable
fun AssistantApp(context: Context) {
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var modelReady by remember { mutableStateOf(File(context.filesDir, MODEL_FILE).exists() || downloadedModel(context).exists()) }
    var downloadStarted by remember { mutableStateOf(false) }
    var messages by remember { mutableStateOf(emptyList<ChatMessage>()) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Мой локальный ассистент") }) }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (!modelReady) {
                    Card(Modifier.fillMaxWidth().padding(12.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Нужна локальная модель Qwen3-4B", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Модель бесплатная и работает на телефоне. Первый запуск потребует скачать около 2,5 ГБ. После загрузки OpenAI API-ключ не нужен.",
                                fontSize = 14.sp
                            )
                            Spacer(Modifier.height(12.dp))
                            Button(
                                enabled = !downloadStarted,
                                onClick = {
                                    downloadStarted = true
                                    val request = DownloadManager.Request(Uri.parse(MODEL_URL))
                                        .setTitle("Qwen3-4B")
                                        .setDescription("Загрузка локальной AI-модели")
                                        .setNotificationVisibility(
                                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                                        )
                                        .setDestinationInExternalFilesDir(
                                            context,
                                            Environment.DIRECTORY_DOWNLOADS,
                                            MODEL_FILE
                                        )
                                    context.getSystemService(DownloadManager::class.java).enqueue(request)
                                }
                            ) {
                                Text(if (downloadStarted) "Загрузка запущена…" else "Скачать модель (≈2,5 ГБ)")
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "После загрузки перезапусти приложение.",
                                fontSize = 12.sp
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.weight(1f).fillMaxWidth().padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messages) { MessageBubble(it) }
                    }

                    Row(
                        Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Напиши сообщение…") },
                            enabled = !busy,
                            maxLines = 4
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(
                            enabled = !busy && input.isNotBlank(),
                            onClick = {
                                val text = input.trim()
                                input = ""
                                messages = messages + ChatMessage("user", text)
                                busy = true
                                scope.launch {
                                    val history = messages.takeLast(12)
                                    val answer = withContext(Dispatchers.Default) {
                                        ensureModel(context)
                                        LocalLlama.generate(
                                            buildPrompt(history),
                                            256
                                        )
                                    }
                                    messages = messages + ChatMessage("assistant", answer)
                                    busy = false
                                }
                            }
                        ) {
                            Text(if (busy) "…" else "Отправить")
                        }
                    }
                }
            }
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }
}

private fun downloadedModel(context: Context): File = File(\n    context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),\n    MODEL_FILE\n)\n\nprivate fun ensureModel(context: Context): Boolean {
    val preferred = File(context.filesDir, MODEL_FILE)
    if (preferred.exists()) return LocalLlama.loadModel(preferred.absolutePath)

    val downloaded = File(
        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
        MODEL_FILE
    )
    if (downloaded.exists()) {
        downloaded.copyTo(preferred, overwrite = true)
        return LocalLlama.loadModel(preferred.absolutePath)
    }
    return false
}

private fun buildPrompt(history: List<ChatMessage>): String {
    return history.joinToString("\n") {
        if (it.role == "user") "Пользователь: ${it.text}"
        else "Ассистент: ${it.text}"
    } + "\nАссистент:"
}

@Composable
fun MessageBubble(message: ChatMessage) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.role == "user") Arrangement.End else Arrangement.Start
    ) {
        Surface(
            tonalElevation = 2.dp,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            Text(message.text, Modifier.padding(12.dp))
        }
    }
}
