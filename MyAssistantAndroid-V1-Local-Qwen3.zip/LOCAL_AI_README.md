# MyAssistant V1 — Local Qwen3

This simplified V1 removes the OpenAI API key and uses a local Qwen3-4B GGUF model through llama.cpp.

Model:
- Qwen3-4B-Q4_K_M.gguf
- approximately 2.5 GB
- Apache 2.0 license
- download source: https://huggingface.co/Qwen/Qwen3-4B-GGUF

The GitHub Actions workflow clones llama.cpp and builds the Android native library for arm64-v8a. The APK downloads the model once to app storage; after that inference is local.

This is an experimental first local build. Voice, long-term memory, and background assistant features are intentionally not included yet.
